-- phpMyAdmin SQL Dump
-- version 3.2.2.1
-- http://www.phpmyadmin.net
--
-- Host: 130.161.159.136
-- Generation Time: May 22, 2014 at 01:53 PM
-- Server version: 5.0.75
-- PHP Version: 5.2.6-3ubuntu4.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `airs2013`
--

-- --------------------------------------------------------

--
-- Table structure for table `duplicate_airs2013`
--

CREATE TABLE IF NOT EXISTS `duplicate_airs2013` (
  `originalTweetId` bigint(20) NOT NULL COMMENT 'The original tweet (may appear in the subtopics assignments table)',
  `duplicateTweetId` bigint(20) NOT NULL COMMENT 'The same subtopic assignments are expected to be added for these tweetId in the qrels.'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `features_tweets2013`
--

CREATE TABLE IF NOT EXISTS `features_tweets2013` (
  `tweetIdA` bigint(20) NOT NULL,
  `tweetIdB` bigint(20) NOT NULL,
  `userIdA` int(11) NOT NULL default '-1',
  `userIdB` int(11) NOT NULL default '-1',
  `levensteinDistance` double NOT NULL default '-1',
  `overlapTerms` double NOT NULL default '-1',
  `overlapHashtags` double NOT NULL default '-1',
  `overlapURLs` double NOT NULL default '-1',
  `overlapExtendedURLs` double NOT NULL default '-1',
  `lengthDifference` double NOT NULL default '-1',
  `overlapDBpediaEntities` double NOT NULL default '-1',
  `overlapDBpediaEntityTypes` double NOT NULL default '-1',
  `overlapOpenCalaisEntities` double NOT NULL default '-1',
  `overlapOpenCalaisTypes` double NOT NULL default '-1',
  `overlapOpenCalaisTopic` double NOT NULL default '-1',
  `overlapWPMEntities` double NOT NULL default '-1',
  `overlapWordNetConcepts` double NOT NULL default '-1',
  `overlapWordNetSynsetConcepts` double NOT NULL default '-1',
  `wordNetSimilarity` double NOT NULL default '-1',
  `overlapEnrichedDBpediaEntities` double NOT NULL default '-1',
  `overlapEnrichedDBpediaEntityTypes` double NOT NULL default '-1',
  `overlapEnrichedOpenCalaisEntities` double NOT NULL default '-1',
  `overlapEnrichedOpenCalaisTypes` double NOT NULL default '-1',
  `overlapEnrichedOpenCalaisTopic` double NOT NULL default '-1',
  `overlapEnrichedWPMEntities` double NOT NULL default '-1',
  `overlapEnrichedWordNetConcepts` double NOT NULL default '-1',
  `overlapEnrichedWordNetSynsetConcepts` double NOT NULL default '-1',
  `enrichedWordNetSimilarity` double NOT NULL default '-1',
  `timeDifference` double NOT NULL default '-1',
  `friendsDifference` double NOT NULL default '-1',
  `followersDifference` double NOT NULL default '-1',
  `sameClient` double NOT NULL default '-1',
  KEY `tweetId` USING HASH (`tweetIdA`,`tweetIdB`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `model_arff_tweets2011`
--

CREATE TABLE IF NOT EXISTS `model_arff_tweets2011` (
  `tweetIdA` bigint(20) NOT NULL COMMENT 'The id of the first tweet in the comparing pair',
  `userIdA` int(11) NOT NULL,
  `tweetIdB` bigint(20) NOT NULL COMMENT 'The id of the second tweet in the comparing pair',
  `userIdB` int(11) NOT NULL,
  `topicId` int(11) NOT NULL,
  `judgement` int(11) NOT NULL,
  `predictedJudgement` int(11) NOT NULL default '-1',
  `levensteinDistance` double NOT NULL default '-1' COMMENT 'The normalised levenstein distance between tweetA and tweetB.',
  `overlapTerms` double NOT NULL default '-1' COMMENT 'The overlap in terms between two tweets, normalized by the average of #term of both tweets.',
  `overlapHashtags` double NOT NULL default '-1' COMMENT 'Overlap in hashtags between tweetA and tweetB, normalized by average of two.',
  `overlapURLs` double NOT NULL default '-1' COMMENT 'Overlap in URLs(not expanded) between tweetA and tweetB; normalized by average.',
  `overlapExtendedURLs` double NOT NULL default '-1' COMMENT 'Overlap in expanded URLs between tweetA and tweetB, normalized by average. ',
  `lengthDifference` double NOT NULL default '-1' COMMENT 'The difference in length between tweetA and tweetB, normalized by the maximum length of tweet (140)',
  `overlapDBpediaEntities` double NOT NULL default '-1',
  `overlapDBpediaEntityTypes` double NOT NULL default '-1',
  `overlapOpenCalaisEntities` double NOT NULL default '-1',
  `overlapOpenCalaisTypes` double NOT NULL default '-1',
  `overlapOpenCalaisTopic` double NOT NULL default '-1',
  `overlapWPMentities` double NOT NULL default '-1',
  `overlapWordNetConcepts` double NOT NULL default '-1',
  `overlapWordNetSynsetConcepts` double NOT NULL default '-1',
  `wordNetSimilarity` double NOT NULL default '-1',
  `timeDifference` double NOT NULL default '-1',
  `friendsDifference` double NOT NULL default '-1',
  `followersDifference` double NOT NULL default '-1',
  `sameClient` double NOT NULL default '-1',
  `overlapEnrichedDBpediaEntities` double NOT NULL default '-1',
  `overlapEnrichedDBpediaEntityTypes` double NOT NULL default '-1',
  `overlapEnrichedOpenCalaisEntities` double NOT NULL default '-1',
  `overlapEnrichedOpenCalaisTypes` double NOT NULL default '-1',
  `overlapEnrichedOpenCalaisTopic` double NOT NULL default '-1',
  `overlapEnrichedWPMEntities` double NOT NULL default '-1',
  `overlapEnrichedWordNetConcepts` double NOT NULL default '-1',
  `overlapEnrichedWordNetSynsetConcepts` double NOT NULL default '-1',
  `enrichedWordNetSimilarity` double NOT NULL default '-1',
  UNIQUE KEY `tweetIdA` (`tweetIdA`,`tweetIdB`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='The duplicate judgement between tweet pairs; generally, twee';

-- --------------------------------------------------------

--
-- Table structure for table `model_enriched_tweets2011`
--

CREATE TABLE IF NOT EXISTS `model_enriched_tweets2011` (
  `id` bigint(20) NOT NULL auto_increment,
  `tweetId` bigint(20) NOT NULL COMMENT 'The tweetId from which this external resource comes from',
  `userId` int(11) NOT NULL COMMENT 'The userId of the tweet''s author who included this url into her tweet',
  `url` text character set utf8 collate utf8_unicode_ci COMMENT 'the url of new entry',
  `title` varchar(400) character set utf8 collate utf8_unicode_ci default NULL COMMENT '''''''''''''''''''''''''''''''''''''''''''''''',
  `newscontent` longtext character set utf8 collate utf8_unicode_ci COMMENT 'the content crawled from the news web page, following the url of the entry',
  `publish_date` datetime default NULL COMMENT 'the publish date of the entry\n',
  `crawl_date` timestamp NULL default CURRENT_TIMESTAMP COMMENT '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''the ',
  PRIMARY KEY  (`id`),
  KEY `index2` (`publish_date`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=1662 ;

-- --------------------------------------------------------

--
-- Table structure for table `model_semantics_enriched_db_tweets2011`
--

CREATE TABLE IF NOT EXISTS `model_semantics_enriched_db_tweets2011` (
  `id` bigint(20) NOT NULL auto_increment,
  `tweetId` bigint(20) NOT NULL,
  `userId` int(11) NOT NULL default '-1',
  `creationTime` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `types` varchar(4096) collate utf8_bin NOT NULL,
  `DBpediaURI` varchar(333) collate utf8_bin NOT NULL,
  `annotatedText` varchar(255) collate utf8_bin NOT NULL,
  `score` double NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `creationTime` (`creationTime`),
  KEY `tweetId` (`tweetId`),
  KEY `userId` (`userId`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='The dbpedia entities in the main content of following URLs i' AUTO_INCREMENT=56082 ;

-- --------------------------------------------------------

--
-- Table structure for table `model_semantics_enriched_oc_entity_tweets2011`
--

CREATE TABLE IF NOT EXISTS `model_semantics_enriched_oc_entity_tweets2011` (
  `tweetId` bigint(20) NOT NULL COMMENT 'the tweetId of the externalResources from which the entity was extracted, points to externalResources.tweetId',
  `type` varchar(255) default NULL COMMENT 'the entity type: person, organization,...',
  `typeURI` varchar(255) default NULL COMMENT 'the URI that corresponds to the type',
  `name` varchar(255) default NULL COMMENT 'the name of the entity',
  `uri` varchar(255) default NULL COMMENT 'uri of the entity (if it is not null then further attributes of the entity can be found in semanticEntityAttributes)',
  `relevance` double default NULL COMMENT 'the probability (estimated by OpenCailais) that the entity really occurs in the news',
  `publish_date` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP COMMENT 'time when the news article was published (see news.publish_date)',
  KEY `tweetIdindex` (`tweetId`),
  KEY `typeindex` (`type`),
  KEY `uriIndex` (`uri`),
  KEY `typeURIIndex` (`typeURI`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='news entity assignments: lists for a given external resource';

-- --------------------------------------------------------

--
-- Table structure for table `model_semantics_enriched_oc_topic_tweets2011`
--

CREATE TABLE IF NOT EXISTS `model_semantics_enriched_oc_topic_tweets2011` (
  `tweetId` bigint(20) NOT NULL COMMENT 'the tweet of the externalResources from which the topic was extracted, points to externalResources_www2013.id',
  `topic` varchar(255) default NULL COMMENT 'the name of the topic/category (categoryName)',
  `uri` varchar(255) default NULL COMMENT 'uri of the topic (if it is not null then further attributes of the topic entity can be found in semanticEntityAttributes)',
  `relevance` double default NULL COMMENT 'the probability (estimated by OpenCailais) that the topic really occurs in the news',
  `publish_date` timestamp NULL default NULL COMMENT 'timestamp of the topic',
  KEY `tweetIdindex` (`tweetId`),
  KEY `topicindex` (`topic`),
  KEY `uriIndex` (`uri`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='news topic assignments: lists for a given news the topics';

-- --------------------------------------------------------

--
-- Table structure for table `model_semantics_enriched_wpm_tweets2011`
--

CREATE TABLE IF NOT EXISTS `model_semantics_enriched_wpm_tweets2011` (
  `id` int(11) NOT NULL auto_increment COMMENT 'Primary key for convenience',
  `tweetid` bigint(20) NOT NULL COMMENT 'The id of the annotated tweet',
  `title` varchar(255) collate utf8_unicode_ci NOT NULL COMMENT 'The title of the wikipedia entry annotated to the tweet',
  `weight` double NOT NULL COMMENT 'A weight corresponding to the annotation',
  `confidence` double NOT NULL COMMENT 'The confidence of disambiguation (average)',
  `probability` double NOT NULL COMMENT 'The link probability (normalised)',
  `timestamp` date NOT NULL COMMENT 'The timestamp of posting the tweet',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='This table stores the result of the annotation to the tweets' AUTO_INCREMENT=114656 ;

-- --------------------------------------------------------

--
-- Table structure for table `model_semantics_tweets_db_tweets2011`
--

CREATE TABLE IF NOT EXISTS `model_semantics_tweets_db_tweets2011` (
  `id` bigint(20) NOT NULL default '0',
  `tweetId` bigint(20) NOT NULL,
  `userId` int(11) NOT NULL default '-1',
  `creationTime` timestamp NOT NULL default '0000-00-00 00:00:00',
  `types` varchar(255) character set utf8 collate utf8_bin NOT NULL,
  `DBpediaURI` varchar(333) character set utf8 collate utf8_bin NOT NULL,
  `annotatedText` varchar(255) character set utf8 collate utf8_bin NOT NULL,
  `score` double NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `model_semantics_tweets_oc_entity_tweets2011`
--

CREATE TABLE IF NOT EXISTS `model_semantics_tweets_oc_entity_tweets2011` (
  `userId` int(11) default NULL,
  `tweetId` bigint(20) NOT NULL COMMENT 'the tweet from which the entity was extracted, points to tweet.id',
  `type` varchar(255) default NULL COMMENT 'the entity type: person, organization,...',
  `typeURI` varchar(255) default NULL COMMENT 'the URI that corresponds to the type',
  `name` varchar(255) default NULL COMMENT 'the name of the entity',
  `uri` varchar(255) default NULL COMMENT 'uri of the entity (if it is not null then further attributes of the entity can be found in semanticEntityAttributes)',
  `relevance` double default NULL COMMENT 'the id of the user who tweeted (points to User.id)',
  `creationTime` timestamp NULL default NULL COMMENT 'timestamp, when the tweet was posted',
  KEY `tweetIdindex` (`tweetId`),
  KEY `typeindex` (`type`),
  KEY `uriIndex` (`uri`),
  KEY `typeURIIndex` (`typeURI`),
  KEY `userIdindex` (`userId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='tweet entity assignments: lists for a given tweet the entiti';

-- --------------------------------------------------------

--
-- Table structure for table `model_semantics_tweets_oc_topic_tweets2011`
--

CREATE TABLE IF NOT EXISTS `model_semantics_tweets_oc_topic_tweets2011` (
  `userId` int(11) default NULL COMMENT 'id of the user who tweeted (points to User.id)',
  `tweetId` bigint(20) NOT NULL COMMENT 'the tweet from which the topic was extracted, points to tweet.id',
  `topic` varchar(255) default NULL COMMENT 'the name of the topic/category (categoryName)',
  `uri` varchar(255) default NULL COMMENT 'uri of the topic (if it is not null then further attributes of the topic entity can be found in semanticEntityAttributes)',
  `relevance` double default NULL COMMENT 'the probability (estimated by OpenCailais) that the topic really occurs in the tweet',
  `creationTime` timestamp NULL default NULL COMMENT 'timestamp, when the tweet was posted',
  KEY `tweetIdindex` (`tweetId`),
  KEY `topicindex` (`topic`),
  KEY `uriIndex` (`uri`),
  KEY `userIdindex` (`userId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='tweet topic assignments: lists for a given tweet the topics';

-- --------------------------------------------------------

--
-- Table structure for table `model_semantics_tweets_wpm_tweets2011`
--

CREATE TABLE IF NOT EXISTS `model_semantics_tweets_wpm_tweets2011` (
  `id` int(11) NOT NULL auto_increment COMMENT 'Primary key for convenience',
  `tweetid` bigint(20) NOT NULL COMMENT 'The id of the annotated tweet',
  `title` varchar(255) collate utf8_unicode_ci NOT NULL COMMENT 'The title of the wikipedia entry annotated to the tweet',
  `weight` double NOT NULL COMMENT 'A weight corresponding to the annotation',
  `confidence` double NOT NULL COMMENT 'The confidence of disambiguation (average)',
  `probability` double NOT NULL COMMENT 'The link probability (normalised)',
  `timestamp` date NOT NULL COMMENT 'The timestamp of posting the tweet',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='This table stores the result of the annotation to the tweets' AUTO_INCREMENT=14989 ;

-- --------------------------------------------------------

--
-- Table structure for table `model_tweets_tweets2011`
--

CREATE TABLE IF NOT EXISTS `model_tweets_tweets2011` (
  `id` bigint(20) NOT NULL COMMENT 'the Twitter ID of this Tweet',
  `userId` bigint(20) default NULL COMMENT 'the ID of the author of this Tweet as given by Twitter.com',
  `username` varchar(255) character set utf8 collate utf8_bin NOT NULL COMMENT 'the Twitter username of the author of this Tweet',
  `content` varchar(255) character set utf8 collate utf8_bin NOT NULL COMMENT 'the content of this Tweet = the actual Tweet',
  `creationTime` timestamp NULL default NULL COMMENT 'timestamp indicating when this Tweet was created',
  `favorite` tinyint(1) NOT NULL default '0' COMMENT '1 = Tweets was marked as favorite, 0 = not marked as favorite',
  `replyToPostId` bigint(20) default NULL COMMENT 'if this Tweet is a reply to another Tweet then this field provides the Twitter post ID of that Tweet',
  `replyToUsername` varchar(255) character set utf8 collate utf8_bin default NULL COMMENT 'if this Tweet is a reply to another Tweet then this field provides the Twitter username of that post',
  `retweetedFromPostId` bigint(20) default NULL COMMENT 'if this post is a re-tweet then this field provides the Twitter ID of the post that was re-tweeted',
  `retweetedFromUsername` varchar(255) character set utf8 collate utf8_bin default NULL COMMENT 'if this post is a re-tweet then this field provides the Twitter username of the author of the post that was re-tweeted',
  `retweetCount` int(11) default NULL COMMENT 'how often has this tweet been re-tweeted already',
  `latitude` double default NULL COMMENT 'latitude of the geographical location where the user was when he published the Tweet',
  `longitude` double default NULL COMMENT 'longitude of the geographical location where the user was when he published the Tweet',
  `placeCountry` varchar(100) character set utf8 collate utf8_bin default NULL COMMENT 'country where the tweet was posted',
  `placeCountryCode` varchar(20) character set utf8 collate utf8_bin default NULL COMMENT 'country code of the place from which the tweet was posted ',
  `placeStreetAddress` varchar(255) character set utf8 collate utf8_bin default NULL COMMENT 'country code of the place from which the tweet was posted',
  `placeURL` varchar(255) character set utf8 collate utf8_bin default NULL COMMENT 'country code of the place from which the tweet was posted',
  `placeGeometryType` varchar(255) character set utf8 collate utf8_bin default NULL COMMENT 'country code of the place from which the tweet was posted',
  `placeName` varchar(255) character set utf8 collate utf8_bin default NULL COMMENT 'country code of the place from which the tweet was posted',
  `placeFullName` varchar(255) character set utf8 collate utf8_bin default NULL COMMENT 'country code of the place from which the tweet was posted',
  `placeId` varchar(255) character set utf8 collate utf8_bin default NULL COMMENT 'country code of the place from which the tweet was posted',
  `source` varchar(255) character set utf8 collate utf8_bin default NULL COMMENT 'source specifies via which service/application a post was created',
  `json` text character set utf8 collate utf8_bin COMMENT 'the complete tweet object in JSON format',
  `timeOfCrawl` timestamp NULL default NULL COMMENT 'when was this tweet added to the DB',
  `crawledViaNewsMedia` tinyint(1) default '0' COMMENT '1 means that the tweet was crawled via Mainstream News Twitter users like CNN, etc. (including re-tweets) and 0 means that we crawled the tweets via the user-specific timelines (without checking whether the tweet is related to news)',
  `language` varchar(16) character set utf8 collate utf8_bin NOT NULL COMMENT 'language detected, english / non-english / not-sure',
  `nFollowers` int(11) default NULL,
  `nFriends` int(11) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `source_semantics_tweets_db`
--

CREATE TABLE IF NOT EXISTS `source_semantics_tweets_db` (
  `id` bigint(20) NOT NULL auto_increment,
  `tweetId` bigint(20) NOT NULL,
  `userId` int(11) NOT NULL default '-1',
  `creationTime` timestamp NOT NULL default '0000-00-00 00:00:00',
  `types` varchar(4196) character set utf8 collate utf8_bin NOT NULL,
  `DBpediaURI` varchar(333) character set utf8 collate utf8_bin NOT NULL,
  `annotatedText` varchar(255) character set utf8 collate utf8_bin NOT NULL,
  `score` double NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=601891 ;

-- --------------------------------------------------------

--
-- Table structure for table `source_semantics_tweets_oc_entity`
--

CREATE TABLE IF NOT EXISTS `source_semantics_tweets_oc_entity` (
  `userId` int(11) default NULL,
  `tweetId` bigint(20) NOT NULL COMMENT 'the tweet from which the entity was extracted, points to tweet.id',
  `type` varchar(255) default NULL COMMENT 'the entity type: person, organization,...',
  `typeURI` varchar(255) default NULL COMMENT 'the URI that corresponds to the type',
  `name` varchar(255) default NULL COMMENT 'the name of the entity',
  `uri` varchar(255) default NULL COMMENT 'uri of the entity (if it is not null then further attributes of the entity can be found in semanticEntityAttributes)',
  `relevance` double default NULL COMMENT 'the id of the user who tweeted (points to User.id)',
  `creationTime` timestamp NULL default NULL COMMENT 'timestamp, when the tweet was posted',
  KEY `tweetIdindex` (`tweetId`),
  KEY `typeindex` (`type`),
  KEY `uriIndex` (`uri`),
  KEY `typeURIIndex` (`typeURI`),
  KEY `userIdindex` (`userId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='tweet entity assignments: lists for a given tweet the entiti';

-- --------------------------------------------------------

--
-- Table structure for table `source_semantics_tweets_oc_topic`
--

CREATE TABLE IF NOT EXISTS `source_semantics_tweets_oc_topic` (
  `userId` int(11) default NULL COMMENT 'id of the user who tweeted (points to User.id)',
  `tweetId` bigint(20) NOT NULL COMMENT 'the tweet from which the topic was extracted, points to tweet.id',
  `topic` varchar(255) default NULL COMMENT 'the name of the topic/category (categoryName)',
  `uri` varchar(255) default NULL COMMENT 'uri of the topic (if it is not null then further attributes of the topic entity can be found in semanticEntityAttributes)',
  `relevance` double default NULL COMMENT 'the probability (estimated by OpenCailais) that the topic really occurs in the tweet',
  `creationTime` timestamp NULL default NULL COMMENT 'timestamp, when the tweet was posted',
  KEY `tweetIdindex` (`tweetId`),
  KEY `topicindex` (`topic`),
  KEY `uriIndex` (`uri`),
  KEY `userIdindex` (`userId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='tweet topic assignments: lists for a given tweet the topics';

-- --------------------------------------------------------

--
-- Table structure for table `source_semantics_tweets_wpm`
--

CREATE TABLE IF NOT EXISTS `source_semantics_tweets_wpm` (
  `id` int(11) NOT NULL auto_increment COMMENT 'Primary key for convenience',
  `tweetid` bigint(20) NOT NULL COMMENT 'The id of the annotated tweet',
  `title` varchar(255) collate utf8_unicode_ci NOT NULL COMMENT 'The title of the wikipedia entry annotated to the tweet',
  `weight` double NOT NULL COMMENT 'A weight corresponding to the annotation',
  `confidence` double NOT NULL COMMENT 'The confidence of disambiguation (average)',
  `probability` double NOT NULL COMMENT 'The link probability (normalised)',
  `timestamp` date NOT NULL COMMENT 'The timestamp of posting the tweet',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='This table stores the result of the annotation to the tweets' AUTO_INCREMENT=896703 ;

-- --------------------------------------------------------

--
-- Table structure for table `source_tweets_uri`
--

CREATE TABLE IF NOT EXISTS `source_tweets_uri` (
  `id` bigint(20) NOT NULL auto_increment COMMENT '''the id of twee',
  `originalUri` varchar(255) collate utf8_unicode_ci default NULL COMMENT 'the original uri contained in the tweet',
  `isShort` tinyint(1) NOT NULL default '1' COMMENT '''''''''''''''''''''''''''''''flag: whether th',
  `expandedUri` varchar(333) collate utf8_unicode_ci default NULL,
  UNIQUE KEY `expandedUri` (`expandedUri`),
  KEY `tweetId` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='the original and expanded URIs contained in the crawled twee' AUTO_INCREMENT=318512593671188482 ;

-- --------------------------------------------------------

--
-- Table structure for table `subtopic_assignments_tweets2013`
--

CREATE TABLE IF NOT EXISTS `subtopic_assignments_tweets2013` (
  `id` int(11) NOT NULL auto_increment COMMENT 'Just ID',
  `tweetId` bigint(20) NOT NULL COMMENT 'The ID of the tweet',
  `subtopic` varchar(255) collate utf8_unicode_ci NOT NULL COMMENT 'A single topic assigned to the tweet specified by the tweetId',
  `topic` varchar(255) collate utf8_unicode_ci NOT NULL COMMENT 'The general topic to which the subtopics belong.',
  `annotator` varchar(255) collate utf8_unicode_ci NOT NULL COMMENT 'The name of the annotator.',
  `ipaddress` varchar(64) collate utf8_unicode_ci NOT NULL COMMENT 'IP address of the annotator',
  `timeUsedForAnnotation` bigint(20) default NULL,
  PRIMARY KEY  (`id`),
  KEY `tweetId` (`tweetId`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=21307 ;

-- --------------------------------------------------------

--
-- Table structure for table `topic`
--

CREATE TABLE IF NOT EXISTS `topic` (
  `id` int(11) NOT NULL auto_increment COMMENT 'The id of the topic',
  `reference` varchar(64) collate utf8_bin NOT NULL COMMENT 'The reference of the topic',
  `topicGroup` varchar(255) collate utf8_bin NOT NULL COMMENT 'The reference of a group of topics',
  `title` varchar(255) collate utf8_bin NOT NULL COMMENT 'The content of the topic',
  `queryTime` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `queryTweetTime` bigint(20) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `reference` (`reference`),
  KEY `queryTime` (`queryTime`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `topic_old`
--

CREATE TABLE IF NOT EXISTS `topic_old` (
  `id` int(11) NOT NULL auto_increment,
  `topic` varchar(255) default NULL,
  `dd` double default NULL COMMENT 'The difficulty to diversify the search results.',
  `temporal_persistence` enum('LONG','SHORT') default NULL,
  `stdNumberOfTopics` double default NULL,
  `avgNumberOfTopics` double default NULL,
  `tp_claudia` enum('LONG','SHORT') default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=51 ;

-- --------------------------------------------------------

--
-- Table structure for table `tweets_airs2013`
--

CREATE TABLE IF NOT EXISTS `tweets_airs2013` (
  `id` bigint(20) NOT NULL COMMENT 'the Twitter ID of this Tweet',
  `userId` bigint(20) default NULL COMMENT 'the ID of the author of this Tweet as given by Twitter.com',
  `username` varchar(255) character set utf8 collate utf8_bin NOT NULL COMMENT 'the Twitter username of the author of this Tweet',
  `content` varchar(255) character set utf8 collate utf8_bin NOT NULL COMMENT 'the content of this Tweet = the actual Tweet',
  `creationTime` timestamp NULL default NULL COMMENT 'timestamp indicating when this Tweet was created',
  `favorite` tinyint(1) NOT NULL default '0' COMMENT '1 = Tweets was marked as favorite, 0 = not marked as favorite',
  `replyToPostId` bigint(20) default NULL COMMENT 'if this Tweet is a reply to another Tweet then this field provides the Twitter post ID of that Tweet',
  `replyToUsername` varchar(255) character set utf8 collate utf8_bin default NULL COMMENT 'if this Tweet is a reply to another Tweet then this field provides the Twitter username of that post',
  `retweetedFromPostId` bigint(20) default NULL COMMENT 'if this post is a re-tweet then this field provides the Twitter ID of the post that was re-tweeted',
  `retweetedFromUsername` varchar(255) character set utf8 collate utf8_bin default NULL COMMENT 'if this post is a re-tweet then this field provides the Twitter username of the author of the post that was re-tweeted',
  `retweetCount` int(11) default NULL COMMENT 'how often has this tweet been re-tweeted already',
  `latitude` double default NULL COMMENT 'latitude of the geographical location where the user was when he published the Tweet',
  `longitude` double default NULL COMMENT 'longitude of the geographical location where the user was when he published the Tweet',
  `placeCountry` varchar(100) character set utf8 collate utf8_bin default NULL COMMENT 'country where the tweet was posted',
  `placeCountryCode` varchar(20) character set utf8 collate utf8_bin default NULL COMMENT 'country code of the place from which the tweet was posted ',
  `placeStreetAddress` varchar(255) character set utf8 collate utf8_bin default NULL COMMENT 'country code of the place from which the tweet was posted',
  `placeURL` varchar(255) character set utf8 collate utf8_bin default NULL COMMENT 'country code of the place from which the tweet was posted',
  `placeGeometryType` varchar(255) character set utf8 collate utf8_bin default NULL COMMENT 'country code of the place from which the tweet was posted',
  `placeName` varchar(255) character set utf8 collate utf8_bin default NULL COMMENT 'country code of the place from which the tweet was posted',
  `placeFullName` varchar(255) character set utf8 collate utf8_bin default NULL COMMENT 'country code of the place from which the tweet was posted',
  `placeId` varchar(255) character set utf8 collate utf8_bin default NULL COMMENT 'country code of the place from which the tweet was posted',
  `source` varchar(255) character set utf8 collate utf8_bin default NULL COMMENT 'source specifies via which service/application a post was created',
  `timeOfCrawl` timestamp NULL default CURRENT_TIMESTAMP COMMENT 'when was this tweet added to the DB',
  `nFollowers` int(11) default NULL,
  `nFriends` int(11) default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `userId` (`userId`),
  KEY `username` (`username`),
  KEY `content` (`content`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='This Table contains Twitter posts of users which we crawled ';
